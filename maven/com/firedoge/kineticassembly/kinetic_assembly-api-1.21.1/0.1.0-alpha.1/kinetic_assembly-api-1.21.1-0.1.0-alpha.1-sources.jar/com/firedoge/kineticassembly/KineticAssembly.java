package com.firedoge.kineticassembly;

import com.firedoge.kineticassembly.mechanics.MechanicsApi;

public final class KineticAssembly {
    public static final String MODID = "kinetic_assembly";

    private KineticAssembly() {
    }

    public static MechanicsApi api() {
        throw new IllegalStateException("KineticAssembly API stub is not backed by the runtime mod");
    }
}
